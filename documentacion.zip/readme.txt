usuario admin: admin

contra admin : admin



librerias necesarias para el pdf:  https://packagist.org/packages/setasign/fpdf


notas: La carpeta vendor la tenemos en el gitignore por problemas, se tendra que instalar la libreria y hacer un composer install.